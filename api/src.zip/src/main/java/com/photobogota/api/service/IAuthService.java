package com.photobogota.api.service;

import com.photobogota.api.dto.LoginRequestDTO;
import com.photobogota.api.dto.LoginResponseDTO;
import com.photobogota.api.dto.LogoutResponseDTO;
import com.photobogota.api.dto.RegistroRequestDTO;
import com.photobogota.api.dto.RegistroResponseDTO;
import com.photobogota.api.dto.SolicitarRecuperacionDTO;
import com.photobogota.api.dto.UsuarioResumenDTO;
import com.photobogota.api.dto.VerificarCodigoDTO;

/**
 * Interfaz para el servicio de autenticación.
 * Define los métodos necesarios para el login de usuarios.
 */
public interface IAuthService {
    
    /**
     * Registra un nuevo usuario en el sistema.
     * 
     * @param dto DTO con los datos del usuario a registrar
     * @return DTO con la respuesta del registro
     */
    RegistroResponseDTO registrar(RegistroRequestDTO dto);

     /**
     * Autentica a un usuario con sus credenciales.
     * 
     * @param request DTO con las credenciales del usuario
     * @return DTO con el token JWT y información del usuario
     */
    LoginResponseDTO login(LoginRequestDTO request);

    /**
     * Refresca el token JWT usando un refresh token.
     * 
     * @param refreshToken El token de refresh
     * @return DTO con el nuevo token JWT y refresh token
     */
    LoginResponseDTO refreshToken(String refreshToken);

    /**
     * Cierra la sesión del usuario revocando el refresh token.
     * 
     * @param refreshToken El token de refresh a revocar
     * @return DTO con el mensaje de confirmación
     */
    LogoutResponseDTO logout(String refreshToken);

    /**
     * Obtiene un resumen de los datos del usuario autenticado.
     * 
     * @param nombreUsuario El nombre de usuario del usuario autenticado
     * @return DTO con los datos básicos del usuario (nombre, foto, rol)
     */
    UsuarioResumenDTO getResumenUsuario(String nombreUsuario);

    /**
     * Solicita un código de recuperación de contraseña.
     * Genera un código, lo guarda y envía por correo electrónico.
     * 
     * @param dto DTO con el email del usuario
     * @return Mensaje de confirmación
     */
    String solicitarRecuperacionContrasena(SolicitarRecuperacionDTO dto);

    /**
     * Verifica el código y cambia la contraseña del usuario.
     * 
     * @param dto DTO con el email, código y nueva contraseña
     * @return Mensaje de confirmación
     */
    String verificarCodigoYCambiarContrasena(VerificarCodigoDTO dto);
}
