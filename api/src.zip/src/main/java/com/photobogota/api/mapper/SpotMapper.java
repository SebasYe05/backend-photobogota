package com.photobogota.api.mapper;

import com.photobogota.api.dto.SpotResumenDTO;
import com.photobogota.api.dto.SpotResponseDTO;
import com.photobogota.api.model.Spot;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring")
public interface SpotMapper {

    // Spot → SpotResumenDTO (para los marcadores del mapa)
    @Mapping(target = "imagen", expression = "java(spot.getImagenes().isEmpty() ? null : spot.getImagenes().get(0))")
    @Mapping(target = "usuarioId", source = "creadorUsername")
    @Mapping(target = "rol", source = "creadorRol")
    @Mapping(target = "createdAt", source = "creadoEn")
    @Mapping(target = "creador", expression = "java(toCreadorDTO(spot))")
    SpotResumenDTO toResumen(Spot spot);

    // Lista de spots → Lista de resúmenes
    List<SpotResumenDTO> toResumenList(List<Spot> spots);

    // Spot → SpotResponseDTO (para el detalle completo)
    @Mapping(target = "imagen", expression = "java(spot.getImagenes().isEmpty() ? null : spot.getImagenes().get(0))")
    @Mapping(target = "resenas", source = "resenas")
    @Mapping(target = "usuarioId", source = "creadorUsername")
    @Mapping(target = "rol", source = "creadorRol")
    @Mapping(target = "createdAt", source = "creadoEn")
    @Mapping(target = "creador", expression = "java(toCreadorDTO(spot))")
    SpotResponseDTO toResponse(Spot spot);

    // Construye el objeto anidado "creador" ({ nombreUsuario, rol }) a partir de los
    // campos planos del Spot, para que el front no dependa de un id opaco (usuarioId)
    default SpotResumenDTO.CreadorDTO toCreadorDTO(Spot spot) {
        if (spot == null || spot.getCreadorUsername() == null) {
            return null;
        }
        SpotResumenDTO.CreadorDTO creador = new SpotResumenDTO.CreadorDTO();
        creador.setNombreUsuario(spot.getCreadorUsername());
        creador.setRol(spot.getCreadorRol());
        return creador;
    }

    // Spot.Resena → SpotResponseDTO.ResenaResponseDTO
    @Mapping(target = "fecha", expression = "java(formatearFecha(resena.getFecha()))")
    SpotResponseDTO.ResenaResponseDTO toResenaResponse(Spot.Resena resena);

    // MapStruct detecta este método automáticamente para mapear la lista de reseñas
    List<SpotResponseDTO.ResenaResponseDTO> toResenaResponseList(List<Spot.Resena> resenas);

    // Lógica de formato de fecha — igual a como lo manejas con toEntity en UsuarioMapper
    default String formatearFecha(LocalDateTime fecha) {
        if (fecha == null) return "Recientemente";
        long dias = ChronoUnit.DAYS.between(fecha.toLocalDate(), LocalDateTime.now().toLocalDate());
        if (dias == 0)   return "Hoy";
        if (dias == 1)   return "Ayer";
        if (dias < 7)    return "Hace " + dias + " días";
        if (dias < 30)   return "Hace " + (dias / 7) + " semanas";
        if (dias < 365)  return "Hace " + (dias / 30) + " meses";
        return "Hace " + (dias / 365) + " años";
    }
}