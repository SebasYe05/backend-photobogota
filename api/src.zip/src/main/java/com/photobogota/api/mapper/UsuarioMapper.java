package com.photobogota.api.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.SubclassMapping;

import com.photobogota.api.dto.PerfilUsuarioDTO;
import com.photobogota.api.dto.RegistroRequestDTO;
import com.photobogota.api.model.Miembro;
import com.photobogota.api.model.Usuario;

@Mapper(componentModel = "spring")
public interface UsuarioMapper {

    // Mapeo de Entidad a DTO
    // Si el objeto real es un Miembro, MapStruct usará toDTO(Miembro)
    // automáticamente
    @SubclassMapping(source = Miembro.class, target = PerfilUsuarioDTO.class)
    @Mapping(target = "rol", expression = "java(usuario.getClass().getSimpleName().toUpperCase())")
    @Mapping(target = "puntos", ignore = true)
    @Mapping(target = "nivel", ignore = true)
    @Mapping(target = "email", ignore = true)
    @Mapping(target = "nombreUsuario", ignore = true)
    @Mapping(target = "totalSpots", ignore = true)
    @Mapping(target = "totalResenas", ignore = true)
    @Mapping(target = "totalGuardados", ignore = true)
    PerfilUsuarioDTO toDTO(Usuario usuario);

    // Mapeo específico para Miembro (para que no pierda puntos ni nivel)
    @Mapping(target = "rol", constant = "MIEMBRO")
    @Mapping(target = "email", ignore = true)
    @Mapping(target = "nombreUsuario", ignore = true)
    @Mapping(target = "totalSpots", ignore = true)
    @Mapping(target = "totalResenas", ignore = true)
    @Mapping(target = "totalGuardados", ignore = true)
    PerfilUsuarioDTO toDTO(Miembro miembro);

    // Mapeo de Registro a Entidad
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "fechaRegistro", expression = "java(java.time.LocalDateTime.now())")
    @Mapping(target = "fotoPerfil", ignore = true)
    @Mapping(target = "biografia", ignore = true)
    @Mapping(target = "estadoCuenta", constant = "true")
    @Mapping(target = "correoConfirmado", constant = "false")
    @Mapping(target = "telefono", ignore = true)
    @Mapping(target = "puntos", ignore = true)
    @Mapping(target = "nivel", ignore = true)
    Miembro toMiembroEntity(RegistroRequestDTO dto);

    // Método genérico que delega a toMiembroEntity (usado para registro de nuevos
    // usuarios)
    default Usuario toEntity(RegistroRequestDTO dto) {
        return toMiembroEntity(dto);
    }
}
