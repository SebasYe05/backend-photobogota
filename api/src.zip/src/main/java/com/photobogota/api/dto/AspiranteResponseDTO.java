package com.photobogota.api.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.photobogota.api.model.EstadoAspirante;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO de respuesta para un aspirante")
public class AspiranteResponseDTO {

    @Schema(description = "ID del aspirante")
    private String id;

    @Schema(description = "Nombres del aspirante", example = "Juan Pablo")
    private String nombres;

    @Schema(description = "Apellidos del aspirante", example = "Marin")
    private String apellidos;

    @Schema(description = "Correo electrónico del aspirante", example = "juanpablo@example.com")
    private String email;

    @Schema(description = "Número de teléfono del aspirante", example = "3001234567")
    private String telefono;

    @Schema(description = "Dirección del aspirante", example = "Calle 123 #45-67")
    private String direccion;

    @Schema(description = "NIT del aspirante", example = "800123456-7")
    private String nit;

    @Schema(description = "Fecha de nacimiento", example = "1988-09-10")
    private LocalDate fechaNacimiento;

    @Schema(description = "Nombre del propietario del negocio", example = "Juan Pablo Marin")
    private String nombrePropietario;

    @Schema(description = "Razón social del negocio", example = "Cafetería Marin S.A.S.")
    private String razonSocial;

    @Schema(description = "Categoría del aspirante", example = "Cafetería")
    private String categoria;

    @Schema(description = "Localidad del aspirante", example = "Kennedy")
    private String localidad;

    @Schema(description = "Ruta del archivo adjunto", example = "/uploads/documento.pdf")
    private String rutaArchivo;

    @Schema(description = "Tipo de archivo adjunto", example = "pdf")
    private String tipoArchivo;

    @Schema(description = "Estado del aspirante", example = "Pendiente")
    private EstadoAspirante estado;

    @Schema(description = "Fecha de solicitud", example = "2026-05-03")
    private LocalDate fechaSolicitud;

    @Schema(description = "Código del aspirante", example = "ASPIRANTE001")
    private String codigo;

    @Schema(description = "Justificación del rechazo o de la corrección solicitada")
    private String motivoDecision;

    @Schema(description = "Moderador/administrador que tomó la última decisión")
    private String decididoPor;

    @Schema(description = "Fecha y hora de la última decisión")
    private LocalDateTime fechaDecision;

    @Schema(description = "Fecha y hora en la que el aspirante reenvió sus documentos tras una corrección")
    private LocalDateTime fechaReenvio;

    @Schema(description = "Cantidad de veces que la solicitud ha sido corregida y reenviada")
    private Integer vecesCorregida;

    @Schema(description = "Comentarios internos entre moderadores, no visibles para el aspirante")
    private List<ComentarioInternoDTO> comentariosInternos;

    @Schema(description = "Fecha y hora en la que se enviaron las credenciales de acceso (cuenta creada)")
    private LocalDateTime fechaEnvioCredenciales;

    @Schema(description = "Nombre de usuario generado para la cuenta de socio, si ya se enviaron las credenciales")
    private String nombreUsuarioGenerado;
}